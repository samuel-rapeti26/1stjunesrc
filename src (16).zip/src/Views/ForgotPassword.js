import React, { useState } from "react";
import { api } from "../api/AxiosManager";
import ChangePassword from "./ChangePassword";
import logo from "../assets/logo.png";

const ForgotPassword = () => {
  const [userId, setUserId] = useState("");
  const [pin, setPin] = useState("");
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const onConfirmClick = async () => {
    try {
      setShowChangePassword(true);
      setErrorMessage("");
      const result = await api.post(`/userauth`, {
        User: userId,
        PIN: pin,
      });
      if (result) {
        setShowChangePassword(true);
      }
    } catch (e) {
      setErrorMessage("Invalid UserId/PIN");
    }
  };
  if (showChangePassword) return <ChangePassword userId={userId} />;
  return (
    <div className="flex  flex-col items-center justify-center w-screen h-screen bg-gray-200 text-gray-700">
      <img src={logo} style={{ width: "300px" }} alt="logo" />
      <div className="flex flex-col bg-white rounded shadow-lg p-12 mt-6">
        <label className="font-semibold text-sm" htmlFor="usernameField">
          Identity (Email / Id)
        </label>
        <input
          className="flex items-center h-12 px-4 w-64 bg-gray-200 mt-2 rounded focus:outline-none  focus:ring-1 focus:shadow-md"
          type="text"
          value={userId}
          onChange={(e) => {
            setUserId(e.target.value);
          }}
        />
        <label className="font-semibold text-sm" htmlFor="usernameField">
          PIN
        </label>
        <input
          className="flex items-center h-12 px-4 w-64 bg-gray-200 mt-2 rounded focus:outline-none  focus:ring-1 focus:shadow-md"
          type="password"
          value={pin}
          onChange={(e) => {
            setPin(e.target.value);
          }}
        />
        {errorMessage && <label className="text-red-600">{errorMessage}</label>}
        <button
          className="cursor-pointer flex items-center justify-center h-12 px-6 w-64 bg-blue-600 mt-8 rounded font-semibold text-sm text-blue-100 hover:bg-blue-700"
          onClick={onConfirmClick}
        >
          Confirm
        </button>
      </div>
    </div>
  );
};

export default ForgotPassword;
