import React  from "react";
import DocViewer, { DocViewerRenderers } from "@cyntler/react-doc-viewer";

function DocxViewer() {
    const docs = [
        {
            uri: "https://github.com/theone3nu/trinu-react-library/blob/main/1.docx?raw=true",
            fileType: "docx",
            fileName: "demo.docx",
        }, // Remote file
    ];

    return (
        <DocViewer
            documents={docs}
            pluginRenderers={DocViewerRenderers}
            style={{ height: 1000 }}
        />
    );
}

export default DocxViewer;
